package dev.lvstrng.Dubara.font;

public final class Fonts {
	public static GlyphPageFontRenderer QUICKSAND = GlyphPageFontRenderer.createFromID("/assets/immediatelyfast/font/font.ttf", 40, false, false, false);
}
