package dev.lvstrng.Dubara.event;

import java.util.EventListener;

public interface Listener extends EventListener {
}
