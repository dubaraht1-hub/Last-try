package dev.lvstrng.Dubara.imixin;


public interface IServerboundMovePlayerPacket {
	void setYRot(float yRot);

	void setXRot(float xRot);

	void setHasRot(boolean hasRot);
}