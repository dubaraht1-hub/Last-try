package me.jellysquid.mods.lithium.module.modules.player;

import me.jellysquid.mods.lithium.event.events.TickListener;
import me.jellysquid.mods.lithium.module.Category;
import me.jellysquid.mods.lithium.module.Module;
import me.jellysquid.mods.lithium.utils.EncryptedString;

public final class Sprint extends Module implements TickListener {
    public Sprint() {
        super(EncryptedString.of("Sprint"), EncryptedString.of("Keeps you sprinting at all times"), -1, Category.MISC);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        mc.player.setSprinting(mc.player.input.pressingForward);
    }
}
