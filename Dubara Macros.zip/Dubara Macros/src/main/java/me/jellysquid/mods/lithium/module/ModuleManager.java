package me.jellysquid.mods.lithium.module;

import me.jellysquid.mods.lithium.Nova;
import me.jellysquid.mods.lithium.event.events.ButtonListener;
import me.jellysquid.mods.lithium.module.modules.client.ClickGUI;
import me.jellysquid.mods.lithium.module.modules.client.Friends;
import me.jellysquid.mods.lithium.module.modules.client.SelfDestruct;
import me.jellysquid.mods.lithium.module.modules.combat.*;
import me.jellysquid.mods.lithium.module.modules.misc.*;
import me.jellysquid.mods.lithium.module.modules.movement.ElytraHelper;
import me.jellysquid.mods.lithium.module.modules.player.*;
import me.jellysquid.mods.lithium.module.modules.render.*;
import me.jellysquid.mods.lithium.module.setting.KeybindSetting;
import me.jellysquid.mods.lithium.utils.EncryptedString;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager implements ButtonListener {
	private final List<Module> modules = new ArrayList<>();

	public ModuleManager() {
		addModules();
		addKeybinds();
	}

	public void addModules() {
		//Combat
		add(new AutoPotRefill());
		add(new ShieldDisabler());
		add(new AutoJumpReset());

		//Player
		add(new AirStuck());
		add(new Speed());
		add(new Flight());
		add(new Sprint());
		add(new WebPlus());
		add(new ElytraPlus());


		//Misc
		add(new AutoXP());
		add(new Freecam());

		//Render
		add(new HUD());
		add(new TargetHud());

		//Client
		add(new ClickGUI());
		add(new Friends());
		add(new SelfDestruct());
	}

	public List<Module> getEnabledModules() {
		return modules.stream()
				.filter(Module::isEnabled)
				.toList();
	}


	public List<Module> getModules() {
		return modules;
	}

	public void addKeybinds() {
		Nova.INSTANCE.getEventManager().add(ButtonListener.class, this);

		for (Module module : modules)
			module.addSetting(new KeybindSetting(EncryptedString.of("Keybind"), module.getKey(), true).setDescription(EncryptedString.of("Key to enabled the module")));
	}

	public List<Module> getModulesInCategory(Category category) {
		return modules.stream()
				.filter(module -> module.getCategory() == category)
				.toList();
	}

	@SuppressWarnings("unchecked")
	public <T extends Module> T getModule(Class<T> moduleClass) {
		return (T) modules.stream()
				.filter(moduleClass::isInstance)
				.findFirst()
				.orElse(null);
	}

	public void add(Module module) {
		modules.add(module);
	}

	@Override
	public void onButtonPress(ButtonEvent event) {
		if(!SelfDestruct.destruct) {
			modules.forEach(module -> {
				if(module.getKey() == event.button && event.action == GLFW.GLFW_PRESS)
					module.toggle();
			});
		}
	}
}
