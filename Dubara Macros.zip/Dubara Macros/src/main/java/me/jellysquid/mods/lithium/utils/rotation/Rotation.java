package me.jellysquid.mods.lithium.utils.rotation;


public record Rotation(double yaw, double pitch) {
}
