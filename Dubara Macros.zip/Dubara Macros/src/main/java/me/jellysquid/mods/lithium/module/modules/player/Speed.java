package me.jellysquid.mods.lithium.module.modules.player;

import me.jellysquid.mods.lithium.event.events.TickListener;
import me.jellysquid.mods.lithium.module.Category;
import me.jellysquid.mods.lithium.module.Module;
import me.jellysquid.mods.lithium.module.setting.NumberSetting;
import me.jellysquid.mods.lithium.utils.EncryptedString;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class Speed extends Module implements TickListener {

    private final NumberSetting speedMultiplier = new NumberSetting(EncryptedString.of("Speed Multiplier"), 1.0, 10.0, 1.0, 0.1);

    public Speed() {
        super(EncryptedString.of("Speed"), EncryptedString.of("Allows the player to move faster with customizable speed"),
                -1,
                Category.PLAYER
        );

        addSettings(speedMultiplier);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null) return;

        Vec3d velocity = player.getVelocity();
        Vec3d horizontal = new Vec3d(velocity.x, 0, velocity.z);

        if (horizontal.length() == 0) return; // Not moving

        // Normalize horizontal movement
        horizontal = horizontal.normalize();

        // Apply yaw rotation
        float yawRad = (float) Math.toRadians(player.getYaw());
        double sinYaw = Math.sin(yawRad);
        double cosYaw = Math.cos(yawRad);

        double newX = horizontal.x * cosYaw - horizontal.z * sinYaw;
        double newZ = horizontal.z * cosYaw + horizontal.x * sinYaw;

        // Apply speed multiplier
        Vec3d newVelocity = new Vec3d(newX, velocity.y, newZ).multiply(speedMultiplier.getValue());

        player.setVelocity(newVelocity);
    }
}
