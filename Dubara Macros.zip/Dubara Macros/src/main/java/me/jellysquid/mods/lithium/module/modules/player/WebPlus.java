package me.jellysquid.mods.lithium.module.modules.player;

import me.jellysquid.mods.lithium.event.events.TickListener;
import me.jellysquid.mods.lithium.module.Category;
import me.jellysquid.mods.lithium.module.Module;
import me.jellysquid.mods.lithium.module.setting.NumberSetting;
import me.jellysquid.mods.lithium.utils.PlayerUtils;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class WebPlus extends Module implements TickListener {

    private final NumberSetting speedMultiplier = new NumberSetting("Speed Multiplier", 0.1, 2.0, 0.6, 0.05);

    public WebPlus() {
        super("Web+",
                "Will Make you a Super Tard Tuff BynBang Naming",
                -1,
                Category.PLAYER
        );
        addSettings(speedMultiplier);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null) return;
        if (PlayerUtils.getInstance().isInCobweb()) {
            player.setSprinting(true);
            if (player.input.pressingForward || player.input.pressingBack || player.input.pressingLeft || player.input.pressingRight) {
                Vec3d addedVelocity = player.getRotationVector().multiply(speedMultiplier.getValue());
                player.setVelocity(player.getVelocity().add(addedVelocity));
            }
        }
    }
}
