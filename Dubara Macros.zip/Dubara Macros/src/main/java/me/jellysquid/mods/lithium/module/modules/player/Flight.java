package me.jellysquid.mods.lithium.module.modules.player;

import me.jellysquid.mods.lithium.event.events.TickListener;
import me.jellysquid.mods.lithium.module.Category;
import me.jellysquid.mods.lithium.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;

public final class Flight extends Module implements TickListener {

    private boolean isFlying = false;

    public Flight() {
        super(
                "Flight",
                "Nigger By B ynBang",
                -1,
                Category.PLAYER
        );
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);

        ClientPlayerEntity player = mc.player;
        if (player != null) {
            player.getAbilities().allowFlying = true;
            player.getAbilities().flying = true;
            isFlying = true;
        }

        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);

        ClientPlayerEntity player = mc.player;
        if (player != null) {
            player.getAbilities().flying = false;
            player.getAbilities().allowFlying = false;
            isFlying = false;
        }

        super.onDisable();
    }

    @Override
    public void onTick() {
    }
}
