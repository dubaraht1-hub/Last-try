package me.jellysquid.mods.lithium.event;

import java.util.EventListener;

public interface Listener extends EventListener {
}
