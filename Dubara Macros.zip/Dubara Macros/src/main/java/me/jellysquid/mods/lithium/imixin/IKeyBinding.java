package me.jellysquid.mods.lithium.imixin;

public interface IKeyBinding {
	boolean isActuallyPressed();

	void resetPressed();
}
