package me.jellysquid.mods.lithium;

import me.jellysquid.mods.lithium.event.EventManager;
import me.jellysquid.mods.lithium.gui.ClickGui;
import me.jellysquid.mods.lithium.managers.FriendManager;
import me.jellysquid.mods.lithium.module.ModuleManager;
import me.jellysquid.mods.lithium.managers.ProfileManager;
import me.jellysquid.mods.lithium.utils.rotation.RotatorManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

import java.io.File;
import java.io.IOException;
import java.net.*;

@SuppressWarnings("all")
public final class Nova {
	public RotatorManager rotatorManager;
	public ProfileManager profileManager;
	public ModuleManager moduleManager;
	public EventManager eventManager;
	public FriendManager friendManager;
	public static MinecraftClient mc;
	public String version = " b1.3";
	public static boolean BETA; 
	public static Nova INSTANCE;
	public boolean guiInitialized;
	public ClickGui clickGui;
	public Screen previousScreen = null;
	public long lastModified;
	public File NovaJar;

	public Nova() throws InterruptedException, IOException {
		INSTANCE = this;
		this.eventManager = new EventManager();
		this.moduleManager = new ModuleManager();
		this.clickGui = new ClickGui();
		this.rotatorManager = new RotatorManager();
		this.profileManager = new ProfileManager();
		this.friendManager = new FriendManager();
		this.getProfileManager().loadProfile();
		this.setLastModified();
		this.guiInitialized = false;
		mc = MinecraftClient.getInstance();
	}

	public ProfileManager getProfileManager() {
		return profileManager;
	}

	public ModuleManager getModuleManager() {
		return moduleManager;
	}

	public FriendManager getFriendManager() {
		return friendManager;
	}

	public EventManager getEventManager() {
		return eventManager;
	}

	public ClickGui getClickGui() {
		return clickGui;
	}

	public void resetModifiedDate() {
		this.NovaJar.setLastModified(lastModified);
	}

	public String getVersion() {
		return version;
	}

	public void setLastModified() {
		try {
			this.NovaJar = new File(Nova.class.getProtectionDomain().getCodeSource().getLocation().toURI());
			this.lastModified = NovaJar.lastModified();
		} catch (URISyntaxException ignored) {}
	}
}