package me.jellysquid.mods.lithium.module.modules.player;

import me.jellysquid.mods.lithium.event.events.TickListener;
import me.jellysquid.mods.lithium.module.Category;
import me.jellysquid.mods.lithium.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;

public final class AirStuck extends Module implements TickListener {

    public AirStuck() {
        super(
                "AirStuck",
                "Not  A Tuff Module Cuz it was made by a FuckTardShit aka Yekla Not REALLY MADe but ai made lmfao",
                -1,
                Category.PLAYER
        );
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        YEYE();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc.player;
        if (player == null) return;

        if (player.isOnGround()) {
            Stopnigger(player);
        }
    }

    private void YEYE() {
        ClientPlayerEntity player = mc.player;
        if (player != null) {
            player.setVelocity(0.0, player.getVelocity().y, 0.0);
        }
    }

    private void Stopnigger(ClientPlayerEntity player) {
        player.setVelocity(0.0, 0.0, 0.0);
        player.setPitch(player.getPitch());
        player.setYaw(player.getYaw());
        player.setHeadYaw(player.getHeadYaw());
    }
}
