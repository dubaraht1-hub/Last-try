package me.jellysquid.mods.lithium.module;

import me.jellysquid.mods.lithium.utils.EncryptedString;

public enum Category {
	COMBAT(EncryptedString.of("Combat")),
	PLAYER(EncryptedString.of("Player")),
	MISC(EncryptedString.of("Misc")),
	RENDER(EncryptedString.of("Render")),
	CLIENT(EncryptedString.of("Client"));
	public final CharSequence name;

	Category(CharSequence name) {
		this.name = name;
	}
}
