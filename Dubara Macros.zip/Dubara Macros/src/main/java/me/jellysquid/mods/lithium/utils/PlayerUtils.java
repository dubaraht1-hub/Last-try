package me.jellysquid.mods.lithium.utils;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class PlayerUtils {

    private static final PlayerUtils INSTANCE = new PlayerUtils();
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private PlayerUtils() {}

    public static PlayerUtils getInstance() {
        return INSTANCE;
    }

    public boolean isElytraFlying() {
        if (mc.player == null || mc.world == null) return false;
        if (mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() != Items.ELYTRA) return false;
        return mc.player.isFallFlying();
    }


    public boolean isInCobweb() {
        if (mc.player == null || mc.world == null) return false;
        Box playerBox = mc.player.getBoundingBox();
        BlockPos playerPos = mc.player.getBlockPos();
        for (int x = playerPos.getX() - 2; x <= playerPos.getX() + 2; x++) {
            for (int y = playerPos.getY() - 1; y <= playerPos.getY() + 4; y++) {
                for (int z = playerPos.getZ() - 2; z <= playerPos.getZ() + 2; z++) {
                    BlockPos checkPos = new BlockPos(x, y, z);
                    if (playerBox.intersects(new Box(checkPos)) && mc.world.getBlockState(checkPos).getBlock() == Blocks.COBWEB) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
