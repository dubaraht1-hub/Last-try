package me.jellysquid.mods.lithium.font;

public final class Fonts {
	public static GlyphPageFontRenderer QUICKSAND = GlyphPageFontRenderer.createFromID("/assets/lithium/font/font.ttf", 40, false, false, false);
}
